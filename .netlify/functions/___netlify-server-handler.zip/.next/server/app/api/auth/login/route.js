var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__0uptw0_._.js")
R.c("server/chunks/_1h0t5we._.js")
R.c("server/chunks/src_lib_validation_ts_0ugplpv._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_03bksrk._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_login_route_actions_1ox7zi0.js")
R.m(30450)
module.exports=R.m(30450).exports
