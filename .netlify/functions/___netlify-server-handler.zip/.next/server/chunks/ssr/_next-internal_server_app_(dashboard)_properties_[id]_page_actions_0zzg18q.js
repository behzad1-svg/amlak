module.exports=[31707,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_properties_%5Bid%5D_page_actions_0zzg18q.js.map